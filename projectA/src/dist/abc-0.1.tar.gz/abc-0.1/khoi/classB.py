'''
Created on Jul 27, 2017

@author: khoi.ngo
'''

class B(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
    @staticmethod
    def printB():
        print("123 B class")