'''
Created on Jul 28, 2017

@author: khoi.ngo
'''
from setuptools import setup

setup(name='abc',
      version='0.1',
      description='Test uploada project',
      url='',
      author='Khoi Ngo',
      author_email='quainhan100@gmail.com',
      license='NAK',
      packages=['khoi'],
      zip_safe=False)